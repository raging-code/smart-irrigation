#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <MFRC522.h>
#include <DHT.h>

// WiFi credentials
const char* ssid = "HUAWEI-2.4G-SW5u";
const char* password = "nrgtnfmly";

// Pin Definitions
#define DHTPIN 4
#define DHTTYPE DHT11
#define RAIN_PIN 34
#define SOIL_MOISTURE_PIN 35
#define PHOTO_RESISTOR_PIN 32
#define WATER_FLOW_PIN 27
#define RELAY_PIN 25

// RFID Pins
#define SS_PIN 5
#define RST_PIN 22

// Sensor Objects
DHT dht(DHTPIN, DHTTYPE);
MFRC522 mfrc522(SS_PIN, RST_PIN);

// Web Server
WebServer server(80);

// Sensor Data Structure
struct SensorData {
  float temperature = 0;
  float humidity = 0;
  int rainValue = 0;
  int soilMoisture = 0;
  int sunlight = 0;
  float waterFlow = 0;
  bool irrigationStatus = false;
  String lastRFID = "";
  float lightLux = 0;
} sensorData;

// User Management
struct User {
  String username;
  String password;
  String rfidTag;
  bool isAdmin;
};

#define MAX_USERS 10
User users[MAX_USERS] = {
  {"user1", "password1", "", false}
};
int userCount = 1;

// Current logged in user
String currentUser = "";

// Weather-Based Irrigation Settings
struct WeatherSettings {
  // Temperature thresholds
  float tempMin = 15.0;      // Minimum temperature (°C)
  float tempMax = 35.0;      // Maximum temperature (°C)
  
  // Humidity thresholds
  float humidMin = 30.0;     // Minimum humidity (%)
  float humidMax = 80.0;     // Maximum humidity (%)
  
  // Light intensity thresholds
  int lightMin = 1000;       // Minimum light (Lux)
  int lightMax = 50000;      // Maximum light (Lux)
  
  // Rain settings
  bool waterWhenRaining = false;  // Allow watering when raining?
  int rainThreshold = 500;        // Rain sensor threshold
  
  // Soil moisture thresholds
  int soilMoistureMin = 30;       // Minimum soil moisture (%)
  int soilMoistureMax = 60;       // Maximum soil moisture (%)
  
  // Setting metadata
  String settingName = "Balanced"; // Name of current setting
  String settingType = "preset";   // "preset" or "custom"
  
  // Basic Settings
  bool autoMode = true;
  int manualDuration = 30;
} settings;

// Variables
unsigned long lastSensorRead = 0;
const unsigned long sensorInterval = 5000;
bool isScanningRFID = false;
String rfidScanPurpose = "";
unsigned long rfidScanStart = 0;
const unsigned long rfidScanTimeout = 30000;

// Water flow variables
float totalWater = 0.0;
bool irrigationActive = false;
unsigned long irrigationEndTime = 0;

// RFID reset variables
unsigned long lastRFIDReset = 0;
const unsigned long rfidResetInterval = 2000;

// ============================================
// FUNCTION PROTOTYPES
// ============================================
void readSensors();
void checkWeatherBasedIrrigation();
void startIrrigation(int duration);
void stopIrrigation();
void handleRFID();
bool isAuthenticated();
void addCorsHeaders();
void handleLogin();
void handleLogout();
void handleSignup();
void getSensorData();
void handleGetSettings();
void handleManualIrrigation();
void handleStopIrrigation();
void handleAutoIrrigation();
void handleSettings();
void handleRFIDScan();
void handleRFIDRegistration();
void handleAccountUpdate();
void handleNotFound();
void setupServerRoutes();
String getRFIDUID();
void resetRFIDReader();
bool initRFID();
void simulateWaterFlow();
float convertToLux(int rawValue);

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("\n\n=== Smart Irrigation System Starting ===");
  
  // Initialize sensors
  dht.begin();
  
  // Initialize RFID
  initRFID();
  
  // Initialize pins
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, HIGH); // Relay OFF initially
  
  pinMode(RAIN_PIN, INPUT);
  pinMode(SOIL_MOISTURE_PIN, INPUT);
  pinMode(PHOTO_RESISTOR_PIN, INPUT);
  pinMode(WATER_FLOW_PIN, INPUT_PULLUP);
  
  // Connect to WiFi with timeout
  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);
  
  WiFi.begin(ssid, password);
  
  unsigned long wifiStart = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - wifiStart < 20000) {
    delay(500);
    Serial.print(".");
  }
  
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("\nWiFi connection FAILED!");
    Serial.println("Continuing without WiFi...");
  } else {
    Serial.println("\nWiFi connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
    Serial.print("MAC Address: ");
    Serial.println(WiFi.macAddress());
  }
  
  // Setup server routes
  setupServerRoutes();
  
  // Handle OPTIONS requests for CORS
  server.onNotFound(handleNotFound);
  
  server.begin();
  Serial.println("HTTP server started on port 80");
  Serial.println("===================================");
  
  // Initial sensor reading
  readSensors();
}

void loop() {
  server.handleClient();
  
  unsigned long currentMillis = millis();
  
  // Read sensors every interval
  if (currentMillis - lastSensorRead >= sensorInterval) {
    readSensors();
    lastSensorRead = currentMillis;
    
    // Auto irrigation logic
    if (settings.autoMode && !irrigationActive) {
      checkWeatherBasedIrrigation();
    }
  }
  
  // Handle RFID scanning
  handleRFID();
  
  // Handle irrigation timeout
  if (irrigationActive && currentMillis >= irrigationEndTime) {
    stopIrrigation();
  }
  
  // Simulate water flow measurement
  if (irrigationActive) {
    simulateWaterFlow();
  }
  
  delay(10);
}

// Convert photoresistor reading to Lux
float convertToLux(int rawValue) {
  float voltage = rawValue * (3.3 / 4095.0);
  float resistance = (3.3 - voltage) * 10000 / voltage;
  float lux = pow(10, (log10(1000000.0 / resistance) * 1.5));
  return lux;
}

// SIMPLIFIED: Check if all weather conditions are suitable for irrigation
void checkWeatherBasedIrrigation() {
  // Check soil moisture - ONLY start watering if below minimum threshold
  bool soilNeedsWater = sensorData.soilMoisture < settings.soilMoistureMin;
  
  // Check if we've already reached maximum soil moisture
  bool soilAtMax = sensorData.soilMoisture >= settings.soilMoistureMax;
  
  // Check temperature range
  bool tempInRange = sensorData.temperature >= settings.tempMin && 
                     sensorData.temperature <= settings.tempMax;
  
  // Check humidity range
  bool humidityInRange = sensorData.humidity >= settings.humidMin && 
                         sensorData.humidity <= settings.humidMax;
  
  // Check light intensity range
  bool lightInRange = sensorData.lightLux >= settings.lightMin && 
                      sensorData.lightLux <= settings.lightMax;
  
  // Check rain condition
  bool rainConditionOK = true;
  if (!settings.waterWhenRaining) {
    rainConditionOK = sensorData.rainValue < settings.rainThreshold;
  }
  
  // ALL conditions must be met to start irrigation
  bool shouldIrrigate = soilNeedsWater && 
                       !soilAtMax && 
                       tempInRange && 
                       humidityInRange && 
                       lightInRange && 
                       rainConditionOK;
  
  if (shouldIrrigate && !irrigationActive) {
    // Fixed duration for weather-based irrigation
    int duration = 60; // 60 seconds default
    startIrrigation(duration);
    
    Serial.println("Weather-based Irrigation started for " + String(duration) + " seconds");
    Serial.println("Conditions met: Temp=" + String(sensorData.temperature) + 
                   "°C, Humid=" + String(sensorData.humidity) + 
                   "%, Light=" + String(sensorData.lightLux) + 
                   " Lux, Soil=" + String(sensorData.soilMoisture) + "%");
  }
}

// Simulate water flow measurement
void simulateWaterFlow() {
  static unsigned long lastFlowUpdate = 0;
  unsigned long currentMillis = millis();
  
  if (currentMillis - lastFlowUpdate >= 1000) {
    sensorData.waterFlow = 2.5;
    totalWater += sensorData.waterFlow / 60.0;
    lastFlowUpdate = currentMillis;
  }
}

bool initRFID() {
  SPI.begin();
  mfrc522.PCD_Init();
  delay(4);
  
  byte v = mfrc522.PCD_ReadRegister(mfrc522.VersionReg);
  if (v == 0x00 || v == 0xFF) {
    Serial.println("RFID module not found or not working!");
    return false;
  }
  
  Serial.print("RFID Module Version: 0x");
  Serial.print(v, HEX);
  Serial.println(" (MIFARE Classic 1K)");
  
  return true;
}

void resetRFIDReader() {
  mfrc522.PCD_Reset();
  delay(50);
  mfrc522.PCD_Init();
  delay(50);
  mfrc522.PCD_SetAntennaGain(mfrc522.RxGain_max);
  mfrc522.PCD_SetRegisterBitMask(mfrc522.TxControlReg, 0x03);
}

String getRFIDUID() {
  static unsigned long lastCardRead = 0;
  unsigned long currentMillis = millis();
  
  if (currentMillis - lastCardRead > rfidResetInterval && currentMillis - lastRFIDReset > rfidResetInterval) {
    resetRFIDReader();
    lastRFIDReset = currentMillis;
  }
  
  if (!mfrc522.PICC_IsNewCardPresent()) {
    return "";
  }
  
  if (!mfrc522.PICC_ReadCardSerial()) {
    return "";
  }
  
  String rfidContent = "";
  for (byte i = 0; i < mfrc522.uid.size; i++) {
    rfidContent += String(mfrc522.uid.uidByte[i] < 0x10 ? "0" : "");
    rfidContent += String(mfrc522.uid.uidByte[i], HEX);
  }
  rfidContent.toUpperCase();
  
  mfrc522.PICC_HaltA();
  mfrc522.PCD_StopCrypto1();
  
  lastCardRead = currentMillis;
  
  return rfidContent;
}

void setupServerRoutes() {
  server.on("/", HTTP_GET, []() {
    addCorsHeaders();
    server.send(200, "application/json", "{\"status\":\"online\",\"device\":\"Smart Irrigation System\"}");
  });
  
  server.on("/api/test", HTTP_GET, []() {
    addCorsHeaders();
    server.send(200, "application/json", "{\"message\":\"Irrigation System is working!\"}");
  });
  
  server.on("/api/login", HTTP_POST, handleLogin);
  server.on("/api/signup", HTTP_POST, handleSignup);
  server.on("/api/sensor-data", HTTP_GET, getSensorData);
  server.on("/api/irrigation/manual", HTTP_POST, handleManualIrrigation);
  server.on("/api/irrigation/stop", HTTP_POST, handleStopIrrigation);
  server.on("/api/irrigation/auto", HTTP_POST, handleAutoIrrigation);
  server.on("/api/settings", HTTP_GET, handleGetSettings);
  server.on("/api/settings", HTTP_POST, handleSettings);
  server.on("/api/rfid/scan", HTTP_POST, handleRFIDScan);
  server.on("/api/rfid/register", HTTP_POST, handleRFIDRegistration);
  server.on("/api/account/update", HTTP_POST, handleAccountUpdate);
  server.on("/api/logout", HTTP_POST, handleLogout);
  
  // New endpoints for presets
  server.on("/api/presets/apply", HTTP_POST, []() {
    addCorsHeaders();
    
    if (server.method() == HTTP_OPTIONS) {
      server.send(200, "text/plain", "");
      return;
    }
    
    if (!isAuthenticated()) {
      server.send(401, "application/json", "{\"success\":false,\"message\":\"Not authenticated\"}");
      return;
    }
    
    if (server.hasArg("plain")) {
      String body = server.arg("plain");
      DynamicJsonDocument doc(1024);
      DeserializationError error = deserializeJson(doc, body);
      
      if (error) {
        server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
        return;
      }
      
      // Apply preset settings
      if (doc.containsKey("tempMin")) settings.tempMin = doc["tempMin"];
      if (doc.containsKey("tempMax")) settings.tempMax = doc["tempMax"];
      if (doc.containsKey("humidMin")) settings.humidMin = doc["humidMin"];
      if (doc.containsKey("humidMax")) settings.humidMax = doc["humidMax"];
      if (doc.containsKey("lightMin")) settings.lightMin = doc["lightMin"];
      if (doc.containsKey("lightMax")) settings.lightMax = doc["lightMax"];
      if (doc.containsKey("waterWhenRaining")) settings.waterWhenRaining = doc["waterWhenRaining"];
      if (doc.containsKey("rainThreshold")) settings.rainThreshold = doc["rainThreshold"];
      if (doc.containsKey("soilMoistureMin")) settings.soilMoistureMin = doc["soilMoistureMin"];
      if (doc.containsKey("soilMoistureMax")) settings.soilMoistureMax = doc["soilMoistureMax"];
      if (doc.containsKey("settingName")) settings.settingName = doc["settingName"].as<String>();
      if (doc.containsKey("settingType")) settings.settingType = doc["settingType"].as<String>();
      
      server.send(200, "application/json", "{\"success\":true,\"message\":\"Preset applied\"}");
    } else {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
    }
  });
  
  server.on("/api/login", HTTP_OPTIONS, []() {
    addCorsHeaders();
    server.send(200, "text/plain", "");
  });
  server.on("/api/signup", HTTP_OPTIONS, []() {
    addCorsHeaders();
    server.send(200, "text/plain", "");
  });
  server.on("/api/presets/apply", HTTP_OPTIONS, []() {
    addCorsHeaders();
    server.send(200, "text/plain", "");
  });
}

void readSensors() {
  // DHT11
  float temp = dht.readTemperature();
  if (!isnan(temp)) {
    sensorData.temperature = temp;
  } else {
    sensorData.temperature = 25.0;
  }
  
  float hum = dht.readHumidity();
  if (!isnan(hum)) {
    sensorData.humidity = hum;
  } else {
    sensorData.humidity = 50.0;
  }
  
  // Rain sensor
  sensorData.rainValue = analogRead(RAIN_PIN);
  
  // Soil moisture
  int soilRaw = analogRead(SOIL_MOISTURE_PIN);
  sensorData.soilMoisture = constrain(map(soilRaw, 4095, 1500, 0, 100), 0, 100);
  
  // Sunlight (convert to Lux)
  int lightRaw = analogRead(PHOTO_RESISTOR_PIN);
  sensorData.sunlight = map(lightRaw, 4095, 0, 0, 100);
  sensorData.lightLux = convertToLux(lightRaw);
  
  // Irrigation status
  sensorData.irrigationStatus = irrigationActive;
  
  // Reset water flow when not irrigating
  if (!irrigationActive) {
    sensorData.waterFlow = 0.0;
  }
}

void startIrrigation(int duration) {
  if (irrigationActive) {
    stopIrrigation();
  }
  
  digitalWrite(RELAY_PIN, LOW); // Relay ON
  irrigationActive = true;
  irrigationEndTime = millis() + (duration * 1000);
  sensorData.irrigationStatus = true;
  
  Serial.println("Irrigation started for " + String(duration) + " seconds");
}

void stopIrrigation() {
  digitalWrite(RELAY_PIN, HIGH); // Relay OFF
  irrigationActive = false;
  sensorData.irrigationStatus = false;
  
  Serial.println("Irrigation stopped");
}

void handleRFID() {
  if (!isScanningRFID) return;
  
  if (millis() - rfidScanStart > rfidScanTimeout) {
    isScanningRFID = false;
    rfidScanPurpose = "";
    Serial.println("RFID scan timeout - resetting module");
    resetRFIDReader();
    return;
  }
  
  String rfid = getRFIDUID();
  if (rfid != "") {
    sensorData.lastRFID = rfid;
    
    Serial.println("RFID scanned: " + rfid + " for purpose: " + rfidScanPurpose);
    
    if (rfidScanPurpose == "registration") {
      for (int i = 0; i < userCount; i++) {
        if (users[i].username == currentUser) {
          users[i].rfidTag = rfid;
          Serial.println("RFID registered for user: " + currentUser);
          break;
        }
      }
    }
    
    if (rfidScanPurpose == "login" || rfidScanPurpose == "registration") {
      isScanningRFID = false;
      rfidScanPurpose = "";
    }
  }
}

bool isAuthenticated() {
  return currentUser != "";
}

void addCorsHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  server.sendHeader("Access-Control-Max-Age", "3600");
}

void handleLogin() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    DynamicJsonDocument doc(256);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }
    
    String username = doc["username"] | "";
    String password = doc["password"] | "";
    String rfid = doc["rfid"] | "";
    
    bool success = false;
    String responseUsername = "";
    bool isAdmin = false;
    
    if (rfid != "") {
      for (int i = 0; i < userCount; i++) {
        if (users[i].rfidTag == rfid) {
          success = true;
          responseUsername = users[i].username;
          isAdmin = users[i].isAdmin;
          currentUser = responseUsername;
          break;
        }
      }
    } else if (username != "" && password != "") {
      for (int i = 0; i < userCount; i++) {
        if (users[i].username == username && users[i].password == password) {
          success = true;
          responseUsername = users[i].username;
          isAdmin = users[i].isAdmin;
          currentUser = responseUsername;
          break;
        }
      }
    }
    
    DynamicJsonDocument responseDoc(256);
    responseDoc["success"] = success;
    if (success) {
      responseDoc["username"] = responseUsername;
      responseDoc["isAdmin"] = isAdmin;
      responseDoc["message"] = "Login successful";
    } else {
      responseDoc["message"] = "Invalid credentials";
    }
    
    String jsonResponse;
    serializeJson(responseDoc, jsonResponse);
    server.send(success ? 200 : 401, "application/json", jsonResponse);
  } else {
    server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
  }
}

void handleLogout() {
  addCorsHeaders();
  currentUser = "";
  server.send(200, "application/json", "{\"success\":true,\"message\":\"Logged out\"}");
}

void handleSignup() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    DynamicJsonDocument doc(256);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }
    
    String username = doc["username"] | "";
    String password = doc["password"] | "";
    
    if (username == "" || password == "") {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Username and password required\"}");
      return;
    }
    
    for (int i = 0; i < userCount; i++) {
      if (users[i].username == username) {
        server.send(400, "application/json", "{\"success\":false,\"message\":\"Username already exists\"}");
        return;
      }
    }
    
    if (userCount < MAX_USERS) {
      users[userCount].username = username;
      users[userCount].password = password;
      users[userCount].rfidTag = "";
      users[userCount].isAdmin = false;
      userCount++;
      
      // Set default balanced settings for new user
      settings.settingName = "Balanced";
      settings.settingType = "preset";
      
      server.send(200, "application/json", "{\"success\":true,\"message\":\"User created successfully\"}");
    } else {
      server.send(500, "application/json", "{\"success\":false,\"message\":\"User limit reached\"}");
    }
  } else {
    server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
  }
}

void getSensorData() {
  addCorsHeaders();
  
  DynamicJsonDocument doc(1024);
  doc["temperature"] = sensorData.temperature;
  doc["humidity"] = sensorData.humidity;
  doc["rain"] = sensorData.rainValue;
  doc["soilMoisture"] = sensorData.soilMoisture;
  doc["sunlight"] = sensorData.sunlight;
  doc["lightLux"] = sensorData.lightLux;
  doc["waterFlow"] = sensorData.waterFlow;
  doc["irrigationStatus"] = sensorData.irrigationStatus;
  doc["autoMode"] = settings.autoMode;
  doc["lastRFID"] = sensorData.lastRFID;
  doc["totalWater"] = totalWater;
  doc["isScanningRFID"] = isScanningRFID;
  doc["rfidScanPurpose"] = rfidScanPurpose;
  
  String jsonResponse;
  serializeJson(doc, jsonResponse);
  server.send(200, "application/json", jsonResponse);
}

void handleGetSettings() {
  addCorsHeaders();
  
  DynamicJsonDocument doc(1024);
  // Temperature thresholds
  doc["tempMin"] = settings.tempMin;
  doc["tempMax"] = settings.tempMax;
  
  // Humidity thresholds
  doc["humidMin"] = settings.humidMin;
  doc["humidMax"] = settings.humidMax;
  
  // Light thresholds
  doc["lightMin"] = settings.lightMin;
  doc["lightMax"] = settings.lightMax;
  
  // Rain settings
  doc["waterWhenRaining"] = settings.waterWhenRaining;
  doc["rainThreshold"] = settings.rainThreshold;
  
  // Soil moisture thresholds
  doc["soilMoistureMin"] = settings.soilMoistureMin;
  doc["soilMoistureMax"] = settings.soilMoistureMax;
  
  // Setting metadata
  doc["settingName"] = settings.settingName;
  doc["settingType"] = settings.settingType;
  
  // Basic Settings
  doc["autoMode"] = settings.autoMode;
  doc["manualDuration"] = settings.manualDuration;
  
  String jsonResponse;
  serializeJson(doc, jsonResponse);
  server.send(200, "application/json", jsonResponse);
}

void handleManualIrrigation() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (!isAuthenticated()) {
    server.send(401, "application/json", "{\"success\":false,\"message\":\"Not authenticated\"}");
    return;
  }
  
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    DynamicJsonDocument doc(256);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }
    
    int duration = doc["duration"] | settings.manualDuration;
    String authType = doc["authType"] | "password";
    String authValue = doc["authValue"] | "";
    
    bool authenticated = false;
    
    if (authType == "password") {
      for (int i = 0; i < userCount; i++) {
        if (users[i].username == currentUser && users[i].password == authValue) {
          authenticated = true;
          break;
        }
      }
    } else if (authType == "rfid") {
      for (int i = 0; i < userCount; i++) {
        if (users[i].username == currentUser && users[i].rfidTag == authValue) {
          authenticated = true;
          break;
        }
      }
    }
    
    if (authenticated) {
      startIrrigation(duration);
      server.send(200, "application/json", "{\"success\":true,\"message\":\"Irrigation started\"}");
    } else {
      server.send(401, "application/json", "{\"success\":false,\"message\":\"Authentication failed\"}");
    }
  } else {
    server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
  }
}

void handleStopIrrigation() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (!isAuthenticated()) {
    server.send(401, "application/json", "{\"success\":false,\"message\":\"Not authenticated\"}");
    return;
  }
  
  stopIrrigation();
  server.send(200, "application/json", "{\"success\":true,\"message\":\"Irrigation stopped\"}");
}

void handleAutoIrrigation() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (!isAuthenticated()) {
    server.send(401, "application/json", "{\"success\":false,\"message\":\"Not authenticated\"}");
    return;
  }
  
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    DynamicJsonDocument doc(256);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }
    
    settings.autoMode = doc["autoMode"] | settings.autoMode;
    
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Auto irrigation updated\"}");
  } else {
    server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
  }
}

void handleSettings() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (!isAuthenticated()) {
    server.send(401, "application/json", "{\"success\":false,\"message\":\"Not authenticated\"}");
    return;
  }
  
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    DynamicJsonDocument doc(1024);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }
    
    // Temperature thresholds
    settings.tempMin = doc["tempMin"] | settings.tempMin;
    settings.tempMax = doc["tempMax"] | settings.tempMax;
    
    // Humidity thresholds
    settings.humidMin = doc["humidMin"] | settings.humidMin;
    settings.humidMax = doc["humidMax"] | settings.humidMax;
    
    // Light thresholds
    settings.lightMin = doc["lightMin"] | settings.lightMin;
    settings.lightMax = doc["lightMax"] | settings.lightMax;
    
    // Rain settings
    settings.waterWhenRaining = doc["waterWhenRaining"] | settings.waterWhenRaining;
    settings.rainThreshold = doc["rainThreshold"] | settings.rainThreshold;
    
    // Soil moisture thresholds
    settings.soilMoistureMin = doc["soilMoistureMin"] | settings.soilMoistureMin;
    settings.soilMoistureMax = doc["soilMoistureMax"] | settings.soilMoistureMax;
    
    // Setting metadata
    settings.settingName = doc["settingName"] | "Customized";
    settings.settingType = doc["settingType"] | "custom";
    
    // Basic Settings
    settings.autoMode = doc["autoMode"] | settings.autoMode;
    settings.manualDuration = doc["manualDuration"] | settings.manualDuration;
    
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Settings saved\"}");
  } else {
    server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
  }
}

void handleRFIDScan() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (!isAuthenticated()) {
    server.send(401, "application/json", "{\"success\":false,\"message\":\"Not authenticated\"}");
    return;
  }
  
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    DynamicJsonDocument doc(256);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }
    
    rfidScanPurpose = doc["purpose"] | "scan";
    isScanningRFID = true;
    rfidScanStart = millis();
    sensorData.lastRFID = "";
    
    resetRFIDReader();
    
    server.send(200, "application/json", "{\"success\":true,\"message\":\"RFID scan started\"}");
  } else {
    server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
  }
}

void handleRFIDRegistration() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (!isAuthenticated()) {
    server.send(401, "application/json", "{\"success\":false,\"message\":\"Not authenticated\"}");
    return;
  }
  
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    DynamicJsonDocument doc(256);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }
    
    String username = doc["username"] | currentUser;
    
    rfidScanPurpose = "registration";
    isScanningRFID = true;
    rfidScanStart = millis();
    sensorData.lastRFID = "";
    
    resetRFIDReader();
    
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Ready to scan RFID for registration\"}");
  } else {
    server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
  }
}

void handleAccountUpdate() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  if (!isAuthenticated()) {
    server.send(401, "application/json", "{\"success\":false,\"message\":\"Not authenticated\"}");
    return;
  }
  
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    DynamicJsonDocument doc(256);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid JSON\"}");
      return;
    }
    
    String username = doc["username"] | currentUser;
    String newPassword = doc["newPassword"] | "";
    
    for (int i = 0; i < userCount; i++) {
      if (users[i].username == username) {
        if (newPassword != "") {
          users[i].password = newPassword;
        }
        
        if (sensorData.lastRFID != "") {
          users[i].rfidTag = sensorData.lastRFID;
          sensorData.lastRFID = "";
        }
        
        server.send(200, "application/json", "{\"success\":true,\"message\":\"Account updated\"}");
        return;
      }
    }
    
    server.send(404, "application/json", "{\"success\":false,\"message\":\"User not found\"}");
  } else {
    server.send(400, "application/json", "{\"success\":false,\"message\":\"No data received\"}");
  }
}

void handleNotFound() {
  addCorsHeaders();
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200, "text/plain", "");
    return;
  }
  
  String message = String("{\"success\":false,\"message\":\"Endpoint not found\",\"method\":\"") +
                 server.method() +
                 "\",\"uri\":\"" +
                 server.uri() +
                 "\"}";

  server.send(404, "application/json", message);
}